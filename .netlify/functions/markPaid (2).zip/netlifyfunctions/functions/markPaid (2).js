// netlify/functions/markPaid.js
const { MongoClient, ObjectId } = require("mongodb");
const jwt = require("jsonwebtoken");

const MONGO_URI = process.env.MONGO_URI;
const JWT_SECRET = process.env.JWT_SECRET;

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      body: JSON.stringify({ error: "Method not allowed" }),
    };
  }

  try {
    // 1. Verify token
    const token = event.headers.authorization?.split(" ")[1];
    if (!token) {
      return { statusCode: 401, body: JSON.stringify({ error: "No token" }) };
    }

    const decoded = jwt.verify(token, JWT_SECRET);
    if (decoded.role !== "buyer") {
      return {
        statusCode: 403,
        body: JSON.stringify({ error: "Only buyers can mark as paid" }),
      };
    }

    // 2. Parse body
    let body;
    try {
      body = JSON.parse(event.body || "{}");
    } catch {
      return { statusCode: 400, body: JSON.stringify({ error: "Invalid JSON body" }) };
    }

    const { escrowId } = body;
    if (!escrowId) {
      return { statusCode: 400, body: JSON.stringify({ error: "Missing escrowId" }) };
    }

    // 3. Connect to DB
    const client = new MongoClient(MONGO_URI);
    await client.connect();
    const db = client.db("escrowApp");
    const escrows = db.collection("escrows");

    // 4. Find escrow
    const escrow = await escrows.findOne({ _id: new ObjectId(escrowId) });
    if (!escrow) {
      await client.close();
      return { statusCode: 404, body: JSON.stringify({ error: "Escrow not found" }) };
    }

    if (escrow.status !== "pending") {
      await client.close();
      return { statusCode: 400, body: JSON.stringify({ error: "Escrow must be pending to mark as paid" }) };
    }

    // 5. Update escrow
    await escrows.updateOne(
      { _id: new ObjectId(escrowId) },
      { $set: { status: "deposit_pending", markedPaidAt: new Date() } }
    );

    const updated = await escrows.findOne({ _id: new ObjectId(escrowId) });
    await client.close();

    return {
      statusCode: 200,
      body: JSON.stringify({
        message: "Escrow marked as paid (deposit pending)",
        escrow: updated,
      }),
    };
  } catch (err) {
    console.error("Error in markPaid:", err);
    return {
      statusCode: 500,
      body: JSON.stringify({
        error: "Internal server error",
        details: err.message,
      }),
    };
  }
};
